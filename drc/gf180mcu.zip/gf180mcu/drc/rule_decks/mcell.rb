# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol mcell]
) do
  #================================================
  #---------------------MCELL----------------------
  #================================================

  # Rule MC.1: min. mcell width is 0.4µm
  logger.info('Executing rule MC.1')
  mc1_l1 = mcell_feol_mk.width(0.4.um, euclidian)
  mc1_l1.output('MC.1', 'MC.1 : min. mcell width : 0.4µm')
  mc1_l1.forget

  # Rule MC.2: min. mcell spacing is 0.4µm
  logger.info('Executing rule MC.2')
  mc2_l1 = mcell_feol_mk.space(0.4.um, euclidian)
  mc2_l1.output('MC.2', 'MC.2 : min. mcell spacing : 0.4µm')
  mc2_l1.forget

  # Rule MC.3: Minimum Mcell area is 0.35µm²
  logger.info('Executing rule MC.3')
  mc3_l1 = mcell_feol_mk.with_area(nil, 0.35.um)
  mc3_l1.output('MC.3', 'MC.3 : Minimum Mcell area : 0.35µm²')
  mc3_l1.forget

  # Rule MC.4: Minimum area enclosed by Mcell is 0.35µm²
  logger.info('Executing rule MC.4')
  mc4_l1 = mcell_feol_mk.holes.with_area(nil, 0.35.um)
  mc4_l1.output('MC.4', 'MC.4 : Minimum area enclosed by Mcell : 0.35µm²')
  mc4_l1.forget
end
