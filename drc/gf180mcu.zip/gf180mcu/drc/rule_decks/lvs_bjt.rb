# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################
GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol lvs_bjt]
) do
  #================================================
  #--------------------LVS_BJT---------------------
  #================================================

  # Rule LVS_BJT.1: Minimum LVS_BJT enclosure of NPN or PNP Emitter COMP layers is 0um.
  logger.info('Executing rule LVS_BJT.1')
  vnpn_e = ncomp.interacting(lvs_bjt).inside(dnwell)
  vpnp_e = pcomp.interacting(lvs_bjt).inside(nwell)
  lvs_l1 = vnpn_e.join(vpnp_e).not(lvs_bjt)
  lvs_l1.output('LVS_BJT.1', 'LVS_BJT.1 : Minimum LVS_BJT enclosure of NPN or PNP Emitter COMP layers: 0um')
  lvs_l1.forget
  vnpn_e.forget
  vpnp_e.forget
end
