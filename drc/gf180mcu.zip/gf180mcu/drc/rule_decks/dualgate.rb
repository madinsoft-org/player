# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol dualgate]
) do
  #================================================
  #--------------------DUALGATE--------------------
  #================================================

  # Rule DV.1: Min. Dualgate enclose DNWELL. is 0.5µm
  logger.info('Executing rule DV.1')
  dv1_l1 = dualgate.enclosing(dnwell, 0.5.um, euclidian).polygons(0.001.um)
  dv1_l2 = dnwell.not_outside(dualgate).not(dualgate)
  dv1_l  = dv1_l1.or(dv1_l2)
  dv1_l.output('DV.1', 'DV.1 : Min. Dualgate enclose DNWELL. : 0.5µm')
  dv1_l1.forget
  dv1_l2.forget
  dv1_l.forget

  # Rule DV.2: Min. Dualgate Space. Merge if Space is less than this design rule. is 0.44µm
  logger.info('Executing rule DV.2')
  dv2_l1 = dualgate.space(0.44.um, euclidian)
  dv2_l1.output('DV.2', 'DV.2 : Min. Dualgate Space. Merge if Space is less than this design rule. : 0.44µm')
  dv2_l1.forget

  # Rule DV.3: Min. Dualgate to COMP space [unrelated]. is 0.24µm
  logger.info('Executing rule DV.3')
  dv3_l1 = dualgate.separation(comp.outside(dualgate), 0.24.um, euclidian)
  dv3_l1.output('DV.3', 'DV.3 : Min. Dualgate to COMP space [unrelated]. : 0.24µm')
  dv3_l1.forget

  # rule DV.4 is not a DRC check
  # Refer to: https://gf180mcu-pdk.readthedocs.io/en/latest/physical_verification/design_manual/drm_07_07.html

  # Rule DV.5: Min. Dualgate width. is 0.7µm
  logger.info('Executing rule DV.5')
  dv5_l1 = dualgate.width(0.7.um, euclidian)
  dv5_l1.output('DV.5', 'DV.5 : Min. Dualgate width. : 0.7µm')
  dv5_l1.forget

  comp_dv = comp.not(pcomp.outside(nwell))
  # Rule DV.6: Min. Dualgate enclose COMP (except substrate tap). is 0.24µm
  logger.info('Executing rule DV.6')
  dv6_l1 = dualgate.enclosing(comp_dv, 0.24.um, euclidian).polygons(0.001.um)
  dv6_l2 = comp_dv.not_outside(dualgate).not(dualgate)
  dv6_l  = dv6_l1.or(dv6_l2)
  dv6_l.output('DV.6', 'DV.6 : Min. Dualgate enclose COMP (except substrate tap). : 0.24µm')
  dv6_l1.forget
  dv6_l2.forget
  dv6_l.forget

  # Rule DV.7: COMP (except substrate tap) can not be partially overlapped by Dualgate.
  logger.info('Executing rule DV.7')
  dv7_l1 = dualgate.not_outside(comp_dv).not(dualgate.covering(comp_dv))
  dv7_l1.output('DV.7', 'DV.7 : COMP (except substrate tap) can not be partially overlapped by Dualgate.')
  dv7_l1.forget

  comp_dv.forget

  # Rule DV.8: Min Dualgate enclose Poly2. is 0.4µm
  logger.info('Executing rule DV.8')
  dv8_l1 = dualgate.enclosing(poly2_drawn, 0.4.um, euclidian).polygons(0.001.um)
  dv8_l2 = poly2_drawn.not_outside(dualgate).not(dualgate)
  dv8_l  = dv8_l1.or(dv8_l2)
  dv8_l.output('DV.8', 'DV.8 : Min Dualgate enclose Poly2. : 0.4µm')
  dv8_l1.forget
  dv8_l2.forget
  dv8_l.forget

  # Rule DV.9: 3.3V and 5V/6V PMOS cannot be sitting inside same NWELL.
  logger.info('Executing rule DV.9')
  dv9_l1 = nwell.covering(pgate.and(dualgate)).covering(pgate.not_inside(v5_xtor).not_inside(dualgate))
  dv9_l1.output('DV.9', 'DV.9 : 3.3V and 5V/6V PMOS cannot be sitting inside same NWELL.')
  dv9_l1.forget
end
