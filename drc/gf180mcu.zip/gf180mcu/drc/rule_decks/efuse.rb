# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all efuse]
) do
  #================================================
  #---------------------EFUSE----------------------
  #================================================

  logger.info('Starting EFUSE derivations')

  efuse_mk_pplus = efuse_mk.and(pplus)
  plfuse_efuse = plfuse.and(efuse_mk)
  poly_efuse = poly2_drawn.and(efuse_mk)
  cathode = poly_efuse.not(lvs_source.join(plfuse))
  anode = poly_efuse.and(lvs_source)
  cathode_edges = cathode.edges
  anode_edges = anode.edges
  plfuse_edges = plfuse.edges

  # Rule EF.01: Min. (Poly2 butt PLFUSE) within EFUSE_MK and Pplus is 0um.
  logger.info('Executing rule EF.01')
  ef01_l1 = poly2_drawn.join(plfuse).interacting(efuse_mk).not_inside(efuse_mk_pplus)
  ef01_l1.output('EF.01', 'EF.01 : Min. (Poly2 butt PLFUSE) within EFUSE_MK and Pplus: 0um')
  ef01_l1.forget

  # Rule EF.02: Min./Max. PLFUSE width. is 0.18µm
  logger.info('Executing rule EF.02')
  ef02_l1 = plfuse.drc(width != 0.18.um)
  ef02_l1.output('EF.02', 'EF.02 : Min./Max. PLFUSE width: 0.18µm')
  ef02_l1.forget

  # Rule EF.03: Min. Max. PLFUSE length. is 1.26µm
  logger.info('Executing rule EF.03')
  ef03_l1 = poly2_drawn.edges.and(plfuse_edges).centers(0, 0.95)
  ef03_l = plfuse_edges.interacting(ef03_l1).without_length(1.26.um)
  ef03_l.output('EF.03', 'EF.03 : Min. Max. PLFUSE length: 1.26µm')
  ef03_l.forget
  ef03_l1.forget

  # Rule EF.04a: Min. Max. PLFUSE overlap Poly2
  ## (coinciding permitted) and touch cathode and anode.
  logger.info('Executing rule EF.04a')
  ef04a_exclude = plfuse.interacting(poly2_drawn.not(plfuse), 2, 2)
  ef04a_l1 = plfuse.not_in(ef04a_exclude).inside(efuse_mk)
  ef04a_l2 = plfuse.not(poly2_drawn).inside(efuse_mk)
  ef04a_l = ef04a_l1.join(ef04a_l2)
  ef04a_l.output('EF.04a', 'EF.04a : Min. Max. PLFUSE overlap Poly2
                  (coinciding permitted) and touch cathode and anode.')
  ef04a_l1.forget
  ef04a_l.forget
  ef04a_l1.forget
  ef04a_l2.forget

  # Rule EF.04b: PLFUSE must be rectangular.
  logger.info('Executing rule EF.04b')
  ef04b_l1 = plfuse.non_rectangles
  ef04b_l1.output('EF.04b', 'EF.04b : PLFUSE must be rectangular.')
  ef04b_l1.forget

  # Rule EF.04c: Cathode Poly2 must be rectangular.
  logger.info('Executing rule EF.04c')
  ef04c_l1 = cathode.non_rectangles
  ef04c_l1.output('EF.04c', 'EF.04c : Cathode Poly2 must be rectangular.')
  ef04c_l1.forget

  # Rule EF.04d: Anode Poly2 must be rectangular.
  logger.info('Executing rule EF.04d')
  ef04d_l1 = anode.non_rectangles
  ef04d_l1.output('EF.04d', 'EF.04d : Anode Poly2 must be rectangular.')
  ef04d_l1.forget

  # Rule EF.05: Min./Max. LVS_Source overlap Poly2 (at Anode) is 0um.
  logger.info('Executing rule EF.05')
  ef05_l1 = poly_efuse.not(plfuse).interacting(lvs_source).not(lvs_source)
  ef05_l2 = lvs_source.not(poly2_drawn).and(efuse_mk)
  ef05_l = ef05_l1.join(ef05_l2)
  ef05_l.output('EF.05', 'EF.05 : Min./Max. LVS_Source overlap Poly2 (at Anode): 0um')
  ef05_l.forget
  ef05_l1.forget
  ef05_l2.forget
  poly_efuse.forget

  # Rule EF.06: Min./Max. Cathode Poly2 width. is 2.26µm
  logger.info('Executing rule EF.06')
  cathode_width = cathode_edges
                  .not_interacting(cathode_edges.interacting(plfuse))
                  .join(cathode_edges.interacting(plfuse))
  ef06_l1 = cathode_width.without_length(2.26.um)
  ef06_l1.output('EF.06', 'EF.06 : Min./Max. Cathode Poly2 width: 2.26µm')
  ef06_l1.forget

  # Rule EF.07: Min./Max. Cathode Poly2 length is 1.84µm.
  logger.info('Executing rule EF.07')
  ef07_l1 = cathode_edges.not(cathode_width).without_length(1.84.um)
  ef07_l1.output('EF.07', 'EF.07 : Min./Max. Cathode Poly2 length: 1.84µm')
  ef07_l1.forget

  # Rule EF.08: Min./Max. Anode Poly2 width is 1.06µm.
  logger.info('Executing rule EF.08')
  anode_width = anode_edges
                .not_interacting(anode_edges.interacting(plfuse))
                .join(anode_edges.interacting(plfuse))
  ef08_l1 = anode_width.without_length(1.06.um)
  ef08_l1.output('EF.08', 'EF.08 : Min./Max. Anode Poly2 width: 1.06µm')
  ef08_l1.forget

  # Rule EF.09: Min./Max. Anode Poly2 length is 2.43µm.
  logger.info('Executing rule EF.09')
  ef09_l1 = anode_edges.not(anode_width).without_length(2.43.um)
  ef09_l1.output('EF.09', 'EF.09 : Min./Max. Anode Poly2 length: 2.43µm')
  ef09_l1.forget
  anode_width.forget

  # Rule EF.10: Min. Cathode Poly2 to Poly2 space. is 0.26µm
  logger.info('Executing rule EF.10')
  ef10_l1 = cathode.space(0.26.um, euclidian)
  ef10_l1.output('EF.10', 'EF.10 : Min. Cathode Poly2 to Poly2 space: 0.26µm')
  ef10_l1.forget

  # Rule EF.11: Min. Anode Poly2 to Poly2 space. is 0.26µm
  logger.info('Executing rule EF.11')
  ef11_l1 = anode.space(0.26.um, euclidian)
  ef11_l1.output('EF.11', 'EF.11 : Min. Anode Poly2 to Poly2 space: 0.26µm')
  ef11_l1.forget

  # Rule EF.12: Min. Space of Cathode Contact to PLFUSE end.
  logger.info('Executing rule EF.12')
  cont_ef = contact.and(plfuse_efuse)
  ef12_l1 = plfuse_efuse.separation(contact.and(cathode), 0.155.um).polygons(0.001.um).join(cont_ef)
  ef12_l1.output('EF.12', 'EF.12 : Min. Space of Cathode Contact to PLFUSE end.')
  ef12_l1.forget

  # Rule EF.13: Min. Space of Anode Contact to PLFUSE end.
  logger.info('Executing rule EF.13')
  ef13_l1 = plfuse_efuse.separation(contact.and(anode), 0.14.um).polygons(0.001.um).join(cont_ef)
  ef13_l1.output('EF.13', 'EF.13 : Min. Space of Anode Contact to PLFUSE end.')
  ef13_l1.forget
  cont_ef.forget

  # Rule EF.14: Min. EFUSE_MK enclose LVS_Source.
  logger.info('Executing rule EF.14')
  ef14_l1 = lvs_source.not_outside(efuse_mk).not(efuse_mk)
  ef14_l1.output('EF.14', 'EF.14 : Min. EFUSE_MK enclose LVS_Source.')
  ef14_l1.forget

  # Rule EF.15: NO Contact is allowed to touch PLFUSE.
  logger.info('Executing rule EF.15')
  ef15_l1 = plfuse.interacting(contact)
  ef15_l1.output('EF.15', 'EF.15 : NO Contact is allowed to touch PLFUSE.')
  ef15_l1.forget

  # Rule EF.16a: Cathode must contain exact number of Contacts at each ends. is 4µm
  logger.info('Executing rule EF.16a')
  ef16a_l1 = cathode.not_covering(contact, 4, 4)
  ef16a_l1.output('EF.16a', 'EF.16a : Cathode must contain exact number of Contacts at each ends: 4µm')
  ef16a_l1.forget

  # Rule EF.16b: Anode must contain exact number of Contacts at each ends. is 4µm
  logger.info('Executing rule EF.16b')
  ef16b_l1 = anode.not_covering(contact, 4, 4)
  ef16b_l1.output('EF.16b', 'EF.16b : Anode must contain exact number of Contacts at each ends: 4µm')
  ef16b_l1.forget

  # Rule EF.17: Min. Space of EFUSE_MK to EFUSE_MK. is 0.26µm
  logger.info('Executing rule EF.17')
  ef17_l1 = efuse_mk.space(0.26.um, euclidian)
  ef17_l1.output('EF.17', 'EF.17 : Min. Space of EFUSE_MK to EFUSE_MK: 0.26µm')
  ef17_l1.forget

  # Rule EF.18: PLFUSE must sit on field oxide (NOT COMP), no cross with any
  ## COMP, Nplus, Pplus, ESD, SAB, Resistor, Metal1, Metal2.
  logger.info('Executing rule EF.18')
  ef18_exclude = comp.join(nplus).join(esd).join(sab).join(resistor).join(metal1).join(metal2)
  ef18_l1 = plfuse.not(plfuse.outside(ef18_exclude))
  ef18_l1.output('EF.18', 'EF.18 : PLFUSE must sit on field oxide (NOT COMP), no cross with any
                  COMP, Nplus, Pplus, ESD, SAB, Resistor, Metal1, Metal2.')
  ef18_l1.forget

  # Rule EF.19: Min. PLFUSE space to Metal1, Metal2.
  logger.info('Executing rule EF.19')
  ef19_l1 = plfuse.not(plfuse.outside(metal1).outside(metal2))
  ef19_l1.output('EF.19', 'EF.19 : Min. PLFUSE space to Metal1, Metal2.')
  ef19_l1.forget

  # Rule EF.20: Min. PLFUSE space to COMP, Nplus, Pplus, Resistor, ESD, SAB. is 2.73µm
  logger.info('Executing rule EF.20')
  ef20_l1 = plfuse.separation(comp + nplus + esd + sab + resistor, 2.73.um, euclidian)
  ef20_l1.output('EF.20', 'EF.20 : Min. PLFUSE space to COMP, Nplus, Pplus, Resistor, ESD, SAB: 2.73µm')
  ef20_l1.forget

  # Rule EF.21: Min./Max. eFUSE Poly2 length. is 5.53µm
  logger.info('Executing rule EF.21')
  ef_21_fuse    = poly2_drawn.interacting(plfuse).inside(efuse_mk_pplus).extents.edges
  ef_21_anode   = anode_edges.not_interacting(anode_edges.interacting(plfuse))
  ef_21_cathode = cathode_edges.not_interacting(cathode_edges.interacting(plfuse))
  ef21_l1 = ef_21_fuse.not_interacting(ef_21_anode.join(ef_21_cathode).centers(0, 0.95)).without_length(5.53.um)
  ef21_l1.output('EF.21', 'EF.21 : Min./Max. eFUSE Poly2 length: 5.53µm')
  ef21_l1.forget
  ef_21_fuse.forget
  ef_21_anode.forget
  ef_21_cathode.forget
  efuse_mk_pplus.forget

  # Rule EF.22a: Min./Max. Cathode Poly2 overlap with PLFUSE in width direction. is 1.04µm
  logger.info('Executing rule EF.22a')
  ef22a_l1 = cathode_edges.interacting(plfuse).not(plfuse_edges).without_length(1.04.um)
  ef22a_l1.output('EF.22a', 'EF.22a : Min./Max. Cathode Poly2 overlap with PLFUSE in width direction: 1.04µm')
  ef22a_l1.forget
  cathode_edges.forget

  # Rule EF.22b: Min./Max. Anode Poly2 overlap with PLFUSE in width direction. is 0.44µm
  logger.info('Executing rule EF.22b')
  ef22b_l1 = anode_edges.interacting(plfuse).not(plfuse_edges).without_length(0.44.um)
  ef22b_l1.output('EF.22b', 'EF.22b : Min./Max. Anode Poly2 overlap with PLFUSE in width direction: 0.44µm')
  ef22b_l1.forget
  plfuse_efuse.forget
  plfuse_edges.forget
  anode_edges.forget
end
