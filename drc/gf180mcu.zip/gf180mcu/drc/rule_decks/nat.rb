# frozen_string_literal: true

################################################################################################
# Copyright 2023 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol nat]
) do
  #================================================
  #-----------------NATIVE VT NMOS-----------------
  #================================================

  logger.info('Starting NAT derivations')

  poly_nat = poly2_drawn.and(nat)
  poly_nat_lv = poly_nat.not_interacting(v5_xtor).not_interacting(dualgate)
  poly_nat_mv = poly_nat.overlapping(dualgate)

  # Rule NAT.1: Min. NAT Overlap of COMP of Native Vt NMOS. is 2µm
  logger.info('Executing rule NAT.1')
  nat1_l1 = ncomp.outside(nwell).interacting(nat).enclosed(nat, 2.um, euclidian)
  nat1_l1.output('NAT.1', 'NAT.1 : Min. NAT Overlap of COMP of Native Vt NMOS. : 2µm')
  nat1_l1.forget

  # Rule NAT.2: Space to unrelated COMP (outside NAT). is 0.3µm
  logger.info('Executing rule NAT.2')
  nat2_l1 = nat.separation(comp.outside(nat), 0.3.um, euclidian)
  nat2_l1.output('NAT.2', 'NAT.2 : Space to unrelated COMP (outside NAT). : 0.3µm')
  nat2_l1.forget

  # Rule NAT.3: Space to NWell edge. is 0.5µm
  logger.info('Executing rule NAT.3')
  nat3_l1 = nat.separation(nwell, 0.5.um, euclidian)
  nat3_l1.output('NAT.3', 'NAT.3 : Space to NWell edge. : 0.5µm')
  nat3_l1.forget

  # Rule NAT.4: Minimum channel length for 3.3V Native Vt NMOS
  ## (For smaller L Ioff will be higher than Spec). is 1.8µm
  logger.info('Executing rule NAT.4')
  nat4_l1 = poly_nat_lv.edges.and(ngate.edges).not(nwell).width(1.8.um, euclidian)
  nat4_l1.output('NAT.4', "NAT.4 : Minimum channel length for 3.3V Native Vt NMOS
                    (For smaller L Ioff will be higher than Spec). : 1.8µm")
  nat4_l1.forget
  poly_nat_lv.forget

  # Rule NAT.5: Minimum channel length for 6.0V Native Vt NMOS
  ## (For smaller L Ioff will be higher than Spec). is 1.8µm
  logger.info('Executing rule NAT.5')
  nat5_l1 = poly_nat_mv.edges.and(ngate.edges).not(nwell).width(1.8.um, euclidian)
  nat5_l1.output('NAT.5', "NAT.5 : Minimum channel length for 6.0V Native Vt NMOS
                    (For smaller L Ioff will be higher than Spec). : 1.8µm")
  nat5_l1.forget
  poly_nat_mv.forget

  _connected_nat, unconnected_nat = conn_space(natcomp_con, 10, 10, transparent)

  # Rule NAT.6: Two or more COMPs if connected to different potential
  ## are not allowed under same NAT layer.
  logger.info('Executing rule NAT.6')
  nat6_l1 = comp.and(nat).interacting(unconnected_nat.inside(nat.covering(comp, 2)).not(poly2_drawn))
  nat6_l1.output('NAT.6', "NAT.6 : Two or more COMPs if connected to different potential
                      are not allowed under same NAT layer.")
  nat6_l1.forget
  natcomp.forget

  # Rule NAT.7: Minimum NAT to NAT spacing. is 0.74µm
  logger.info('Executing rule NAT.7')
  nat7_l1 = nat.space(0.74.um, euclidian)
  nat7_l1.output('NAT.7', 'NAT.7 : Minimum NAT to NAT spacing. : 0.74µm')
  nat7_l1.forget

  # Rule NAT.8: Min. Dualgate overlap of NAT (for 5V/6V) native VT NMOS only is 0um.
  logger.info('Executing rule NAT.8')
  nat8_l1 = nat.not_outside(dualgate).not(dualgate)
  nat8_l1.output('NAT.8', 'NAT.8 : Min. Dualgate overlap of NAT (for 5V/6V) native VT NMOS only: 0um')
  nat8_l1.forget

  # Rule NAT.9: Poly interconnect under NAT layer is not allowed,
  ## minimum spacing of un-related poly from the NAT layer is 0.3um
  logger.info('Executing rule NAT.9')
  nat9_a = poly2_drawn.and(nat).not(ncomp).interacting(ngate.and(nat), 2)
  nat9_b = poly2_drawn.not(nat).separation(nat, 0.3.um, euclidian).polygons(0.001.um)
  nat9_l1 = nat9_a.join(nat9_b)
  nat9_l1.output('NAT.9', "NAT.9 : Poly interconnect under NAT layer is not allowed,
                    minimum spacing of un-related poly from the NAT layer: 0.3um")
  nat9_l1.forget
  nat9_a.forget
  nat9_b.forget

  # Rule NAT.10: Nwell inside NAT layer are not allowed.
  logger.info('Executing rule NAT.10')
  nat10_l1 = nwell.and(nat)
  nat10_l1.output('NAT.10', 'NAT.10 : Nwell inside NAT layer are not allowed.')
  nat10_l1.forget

  # Rule NAT.11: NCOMP not intersecting to Poly2, is not allowed inside NAT layer.
  logger.info('Executing rule NAT.11')
  nat11_l1 = ncomp.and(nat).not_interacting(poly2_drawn)
  nat11_l1.output('NAT.11', 'NAT.11 : NCOMP not intersecting to Poly2, is not allowed inside NAT layer.')
  nat11_l1.forget

  # Rule NAT.12: Poly2 not intersecting with COMP is not allowed inside NAT
  ## (Poly2 resistor is not allowed inside NAT).
  logger.info('Executing rule NAT.12')
  nat12_l1 = poly_nat.not_interacting(comp).or(poly_nat.and(res_mk))
  nat12_l1.output('NAT.12', "NAT.12 : Poly2 not intersecting with COMP is not allowed inside NAT
                     (Poly2 resistor is not allowed inside NAT).")
  nat12_l1.forget
  poly_nat.forget
end
