# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol nplus]
) do
  #================================================
  #---------------------NPLUS----------------------
  #================================================

  logger.info('Starting NPLUS derivations')

  nplus_edges = nplus.edges
  pcomp_edges = pcomp.edges
  nplus_n_dn = nplus.not(dnwell)
  ncomp_butted = ncomp.interacting(pcomp)
  nplus_butted_edges = nplus.edges.and(pcomp.edges)
  nwell_n_dn_sized_out = nwell_n_dn.sized(0.429.um)
  nwell_n_dn_sized_in  = nwell_n_dn.sized(-0.429.um)
  lvpwell_dn_sized_out = lvpwell_dn.sized(0.429.um)
  lvpwell_dn_sized_in  = lvpwell_dn.sized(-0.429.um)

  # Rule NP.1: min. nplus width is 0.4µm
  logger.info('Executing rule NP.1')
  np1_l1 = nplus.width(0.4.um, euclidian)
  np1_l1.output('NP.1', 'NP.1 : min. nplus width : 0.4µm')
  np1_l1.forget

  # Rule NP.2: min. nplus spacing is 0.4µm
  logger.info('Executing rule NP.2')
  np2_l1 = nplus.space(0.4.um, euclidian)
  np2_l1.output('NP.2', 'NP.2 : min. nplus spacing : 0.4µm')
  np2_l1.forget

  # Rule NP.3a: Space to PCOMP for PCOMP:
  ## (1) Inside Nwell (2) Outside LVPWELL but inside DNWELL. is 0.16µm
  logger.info('Executing rule NP.3a')
  np3_nplus = nplus.not_interacting(ncomp_butted)
  np3a_pcomp = pcomp.and(nwell).join(pcomp.not(lvpwell).and(dnwell))
  np3a_l1 = np3_nplus.separation(np3a_pcomp, 0.16.um, euclidian)
  np3a_l1.output('NP.3a', 'NP.3a : Space to PCOMP for PCOMP:
                  (1) Inside Nwell (2) Outside LVPWELL but inside DNWELL. : 0.16µm')
  np3a_l1.forget
  np3a_pcomp.forget

  # Rule NP.3bi: Space to PCOMP: For Inside DNWELL, inside LVPWELL:
  ## (i) For PCOMP overlap by LVPWELL < 0.43um is 0.16µm.
  logger.info('Executing rule NP.3bi')
  np_3bi_pcomp = pcomp.and(lvpwell_dn.not(lvpwell_dn_sized_in))
  np3bi_l1 = np3_nplus.and(lvpwell_dn).separation(np_3bi_pcomp, 0.16.um, euclidian)
  np3bi_l1.output('NP.3bi', 'NP.3bi : Space to PCOMP: For Inside DNWELL, inside LVPWELL:
                   (i) For PCOMP overlap by LVPWELL < 0.43um. : 0.16µm')
  np3bi_l1.forget
  np_3bi_pcomp.forget

  # Rule NP.3bii: Space to PCOMP: For Inside DNWELL, inside LVPWELL:
  ## (ii) For PCOMP overlap by LVPWELL >= 0.43um. is 0.08µm
  logger.info('Executing rule NP.3bii')
  np_3bii_pcomp = pcomp.and(lvpwell_dn_sized_in)
  np3bii_l1 = np3_nplus.and(lvpwell_dn).separation(np_3bii_pcomp, 0.08.um, euclidian)
  np3bii_l1.output('NP.3bii', 'NP.3bii : Space to PCOMP: For Inside DNWELL, inside LVPWELL:
                    (ii) For PCOMP overlap by LVPWELL >= 0.43um. : 0.08µm')
  np3bii_l1.forget
  np_3bii_pcomp.forget

  # Rule NP.3ci: Space to PCOMP: For Outside DNWELL:
  ## (i) For PCOMP space to Nwell < 0.43um. is 0.16µm
  logger.info('Executing rule NP.3ci')
  np_3ci_pcomp = pcomp.not(dnwell).and(nwell_n_dn_sized_out)
  np3ci_l1 = np3_nplus.not(dnwell).separation(np_3ci_pcomp, 0.16.um, euclidian)
  np3ci_l1.output('NP.3ci', 'NP.3ci : Space to PCOMP: For Outside DNWELL:
                   (i) For PCOMP space to Nwell < 0.43um. : 0.16µm')
  np3ci_l1.forget
  np_3ci_pcomp.forget

  # Rule NP.3cii: Space to PCOMP: For Outside DNWELL:
  ## (ii) For PCOMP space to Nwell >= 0.43um. is 0.08µm
  logger.info('Executing rule NP.3cii')
  np_3cii_pcomp = pcomp.not(dnwell).not(nwell_n_dn_sized_out)
  np3cii_l1 = np3_nplus.not(dnwell).separation(np_3cii_pcomp, 0.08.um, euclidian)
  np3cii_l1.output('NP.3cii', 'NP.3cii : Space to PCOMP: For Outside DNWELL:
                    (ii) For PCOMP space to Nwell >= 0.43um. : 0.08µm')
  np3cii_l1.forget
  np_3cii_pcomp.forget

  # Rule NP.3d: Min/max space to a butted PCOMP is 0um.
  logger.info('Executing rule NP.3d')
  np3d_l1 = ncomp.and(pcomp)
  np3d_l1.output('NP.3d', 'NP.3d : Min/max space to a butted PCOMP: 0um')
  np3d_l1.forget

  # Rule NP.3e: Space to related PCOMP edge adjacent to a butting edge is 0um.
  logger.info('Executing rule NP.3e')
  np3e_l1 = nplus.and(pcomp)
  np3e_l1.output('NP.3e', 'NP.3e : Space to related PCOMP edge adjacent to a butting edge: 0um')
  np3e_l1.forget

  # Rule NP.4a: Space to related P-channel gate at a butting edge parallel to gate. is 0.32µm
  logger.info('Executing rule NP.4a')
  np4a_l1 = nplus_edges.and(pcomp_edges).separation(pgate.edges, 0.32.um, projection)
  np4a_l1.output('NP.4a', 'NP.4a : Space to related P-channel gate at a butting edge parallel to gate. : 0.32µm')
  np4a_l1.forget

  # Rule NP.4b: Within 0.32um of channel, space to P-channel gate extension perpendicular
  ## to the direction of Poly2.
  np_4b_poly = poly2_drawn.edges.interacting(pgate.edges.not(pcomp_edges)).centers(0, 0.99).and(pgate.sized(0.32.um))
  logger.info('Executing rule NP.4b')
  np4b_l1 = nplus.interacting(nplus_edges.separation(np_4b_poly, 0.22.um, projection).polygons(0.001.um))
  np4b_l1.output('NP.4b', 'NP.4b : Within 0.32um of channel, space to P-channel gate extension perpendicular
                  to the direction of Poly2.')
  np4b_l1.forget
  np_4b_poly.forget

  # Rule NP.5a: Overlap of N-channel gate. is 0.23µm
  logger.info('Executing rule NP.5a')
  np5a_l1 = ngate.enclosed(nplus, 0.23.um, euclidian).polygons(0.001.um)
  np5a_l2 = ngate.not_outside(nplus).not(nplus)
  np5a_l  = np5a_l1.or(np5a_l2)
  np5a_l.output('NP.5a', 'NP.5a : Overlap of N-channel gate. : 0.23µm')
  np5a_l1.forget
  np5a_l2.forget
  np5a_l.forget

  # Rule NP.5b: Extension beyond COMP for the COMP
  ## (1) inside LVPWELL (2) outside Nwell and DNWELL is 0.16µm.
  logger.info('Executing rule PP.5b')
  np5b_nplus_slct = nplus.edges.not(nplus_butted_edges)
  np5b_nplus = np5b_nplus_slct.and(lvpwell).join(np5b_nplus_slct.not(nwell).not(dnwell))
  np5b_l1 = ncomp.edges.enclosed(np5b_nplus, 0.16.um, projection)
  np5b_l1.output('NP.5b', 'NP.5b : Extension beyond COMP for the COMP
                  (1) inside LVPWELL (2) outside Nwell and DNWELL. : 0.16µm')
  np5b_l1.forget
  np5b_nplus.forget
  np5b_nplus_slct.forget

  # Rule NP.5ci: Extension beyond COMP: For Inside DNWELL: (i)For Nplus < 0.43um
  ## from LVPWELL edge for Nwell or DNWELL tap inside DNWELL. is 0.16µm
  logger.info('Executing rule NP.5ci')
  np_5ci_background = nplus.not_inside(lvpwell).inside(dnwell).edges
  np_5ci_foreground = ncomp.not_inside(lvpwell).inside(dnwell).edges.not(pplus.edges).and(lvpwell_dn_sized_out)
  np5ci_l1 = np_5ci_background.enclosing(np_5ci_foreground, 0.16.um, projection)
  np5ci_l1.output('NP.5ci', 'NP.5ci : Extension beyond COMP: For Inside DNWELL: (i)For Nplus < 0.43um
                   from LVPWELL edge for Nwell or DNWELL tap inside DNWELL. : 0.16µm')
  np5ci_l1.forget
  np_5ci_background.forget
  np_5ci_foreground.forget

  # Rule NP.5cii: Extension beyond COMP: For Inside DNWELL: (ii) For Nplus >= 0.43um
  ## from LVPWELL edge for Nwell or DNWELL tap inside DNWELL. is 0.02µm
  logger.info('Executing rule NP.5cii')
  np_5cii_background = nplus.not_inside(lvpwell).inside(dnwell).edges
  np_5cii_foreground = ncomp.not_inside(lvpwell).inside(dnwell).edges.not(pplus.edges).not(lvpwell_dn_sized_out)
  np5cii_l1 = np_5cii_background.enclosing(np_5cii_foreground, 0.02.um, projection)
  np5cii_l1.output('NP.5cii', 'NP.5cii : Extension beyond COMP: For Inside DNWELL: (ii) For Nplus >= 0.43um
                    from LVPWELL edge for Nwell or DNWELL tap inside DNWELL. : 0.02µm')
  np5cii_l1.forget
  np_5cii_background.forget
  np_5cii_foreground.forget
  lvpwell_dn_sized_out.forget

  # Rule NP.5di: Extension beyond COMP: For Outside DNWELL, inside Nwell:
  ## (i) For Nwell overlap of Nplus < 0.43um. is 0.16µm
  logger.info('Executing rule NP.5di')
  np_5di_background = nplus_n_dn.not_outside(nwell).edges
  np_5di_extend     = nwell_n_dn.not(nwell_n_dn_sized_in)
  np_5di_foreground = ncomp.not_outside(nwell).outside(dnwell).edges.not(pplus.edges).and(np_5di_extend)
  np5di_l1 = np_5di_background.enclosing(np_5di_foreground, 0.16.um, projection)
  np5di_l1.output('NP.5di', 'NP.5di : Extension beyond COMP: For Outside DNWELL, inside Nwell:
                  (i) For Nwell overlap of Nplus < 0.43um. : 0.16µm')
  np5di_l1.forget
  np_5di_background.forget
  np_5di_extend.forget
  np_5di_foreground.forget

  # Rule NP.5dii: Extension beyond COMP: For Outside DNWELL, inside Nwell:
  ## (ii) For Nwell overlap of Nplus >= 0.43um. is 0.02µm
  logger.info('Executing rule NP.5dii')
  np_5dii_background = nplus_n_dn.not_outside(nwell).edges.not(pplus.edges)
  np_5dii_foreground = ncomp.not_outside(nwell).outside(dnwell).edges.not(pplus.edges).and(nwell_n_dn_sized_in)
  np5dii_l1 = np_5dii_background.enclosing(np_5dii_foreground, 0.02.um, euclidian)
  np5dii_l1.output('NP.5dii', 'NP.5dii : Extension beyond COMP: For Outside DNWELL, inside Nwell:
                    (ii) For Nwell overlap of Nplus >= 0.43um. : 0.02µm')
  np5dii_l1.forget
  np_5dii_background.forget
  nwell_n_dn_sized_in.forget
  np_5dii_foreground.forget
  nplus_n_dn.forget

  # Rule NP.6: Overlap with NCOMP butted to PCOMP. is 0.22µm
  logger.info('Executing rule NP.6')
  np6_l1 = comp.interacting(nplus).enclosing(pcomp.interacting(nplus), 0.22.um, projection).polygons
  np6_l1.output('NP.6', 'NP.6 : Overlap with NCOMP butted to PCOMP. : 0.22µm')
  np6_l1.forget

  # Rule NP.7: Space to unrelated unsalicided Poly2. is 0.18µm
  logger.info('Executing rule NP.7')
  np7_l1 = nplus.separation(poly2_drawn.and(sab), 0.18.um, euclidian)
  np7_l1.output('NP.7', 'NP.7 : Space to unrelated unsalicided Poly2. : 0.18µm')
  np7_l1.forget

  # Rule NP.8a: Minimum Nplus area (um2). is 0.35µm²
  logger.info('Executing rule NP.8a')
  np8a_l1 = nplus.with_area(nil, 0.35.um)
  np8a_l1.output('NP.8a', 'NP.8a : Minimum Nplus area (um2). : 0.35µm²')
  np8a_l1.forget

  # Rule NP.8b: Minimum area enclosed by Nplus (um2). is 0.35µm²
  logger.info('Executing rule NP.8b')
  np8b_l1 = nplus.holes.raw.with_area(nil, 0.35.um)
  np8b_l1.output('NP.8b', 'NP.8b : Minimum area enclosed by Nplus (um2). : 0.35µm²')
  np8b_l1.forget

  # Rule NP.9: Overlap of unsalicided Poly2. is 0.18µm
  logger.info('Executing rule NP.9')
  np9_l1 = nplus.enclosing(poly2_drawn.and(sab), 0.18.um, euclidian).polygons(0.001.um)
  np9_l2 = poly2_drawn.and(sab).not_outside(nplus).not(nplus)
  np9_l  = np9_l1.or(np9_l2)
  np9_l.output('NP.9', 'NP.9 : Overlap of unsalicided Poly2. : 0.18µm')
  np9_l1.forget
  np9_l2.forget
  np9_l.forget

  # Rule NP.10: Overlap of unsalicided COMP. is 0.18µm
  logger.info('Executing rule NP.10')
  np10_l1 = nplus.enclosing(comp.and(sab), 0.18.um, euclidian)
  np10_l1.output('NP.10', 'NP.10 : Overlap of unsalicided COMP. : 0.18µm')
  np10_l1.forget

  # Rule NP.11: Butting Nplus and PCOMP is forbidden within 0.43um of Nwell edge (for outside DNWELL)
  ## and of LVPWELL edge (for inside DNWELL case).
  logger.info('Executing rule NP.11')
  np_11_nwell_exclusion_area = nwell_n_dn_sized_out.not(nwell_n_dn)
  np_11_lvpwell_exclude_area = lvpwell_dn.not(lvpwell_dn_sized_in)
  np11_l1 = nplus_butted_edges.and(np_11_nwell_exclusion_area)
  np11_l2 = nplus_butted_edges.and(np_11_lvpwell_exclude_area)
  np11_l = np11_l1.join(np11_l2)
  np11_l.output('NP.11',
                'NP.11 : Butting Nplus and PCOMP is forbidden within 0.43um of Nwell edge (for outside DNWELL)
                  and of LVPWELL edge (for inside DNWELL case).')
  np11_l.forget
  np11_l1.forget
  np11_l2.forget
  np_11_nwell_exclusion_area.forget
  np_11_lvpwell_exclude_area.forget
  nplus_butted_edges.forget
  nwell_n_dn_sized_out.forget
  lvpwell_dn_sized_in.forget

  # Rule NP.12: Overlap with P-channel poly2 gate extension is forbidden
  ## within 0.32um of P-channel gate.
  logger.info('Executing rule NP.12')
  np12_l1 = nplus.interacting(pgate.sized(0.32.um - 1.dbu, size_inside(poly2_drawn), steps(3)))
  np12_l1.output('NP.12', 'NP.12 : Overlap with P-channel poly2 gate extension is forbidden
                  within 0.32um of P-channel gate.')
  np12_l1.forget
  nplus_edges.forget
  pcomp_edges.forget
end
