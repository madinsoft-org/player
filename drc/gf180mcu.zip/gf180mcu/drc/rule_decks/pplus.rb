# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol pplus]
) do
  #================================================
  #---------------------PPLUS----------------------
  #================================================

  logger.info('Starting PPLUS derivations')

  nplus_edges = nplus.edges
  pplus_edges = pplus.edges
  ncomp_edges = ncomp.edges
  pcomp_butted = pcomp.interacting(ncomp)
  pplus_butted_edges = pplus.edges.and(ncomp.edges)
  nwell_n_dn_sized_out = nwell_n_dn.sized(0.429.um)
  nwell_n_dn_sized_in  = nwell_n_dn.sized(-0.429.um)
  lvpwell_dn_sized_out = lvpwell_dn.sized(0.429.um)
  lvpwell_dn_sized_in  = lvpwell_dn.sized(-0.429.um)

  # Rule PP.1: min. pplus width is 0.4µm
  logger.info('Executing rule PP.1')
  pp1_l1 = pplus.width(0.4.um, euclidian)
  pp1_l1.output('PP.1', 'PP.1 : min. pplus width : 0.4µm')
  pp1_l1.forget

  # Rule PP.2: min. pplus spacing is 0.4µm
  logger.info('Executing rule PP.2')
  pp2_l1 = pplus.space(0.4.um, euclidian)
  pp2_l1.output('PP.2', 'PP.2 : min. pplus spacing : 0.4µm')
  pp2_l1.forget

  # Rule PP.3a: Space to NCOMP for NCOMP (1) inside LVPWELL (2) outside NWELL and DNWELL. is 0.16µm
  logger.info('Executing rule PP.3a')
  pp3_pplus = pplus.not_interacting(pcomp_butted)
  pp3a_ncomp = ncomp.and(lvpwell).join(ncomp.not(nwell_n_dn))
  pp3a_l1 = pp3_pplus.separation(pp3a_ncomp, 0.16.um, euclidian)
  pp3a_l1.output('PP.3a',
                 'PP.3a : Space to NCOMP for NCOMP (1) inside LVPWELL (2) outside NWELL and DNWELL: 0.16µm')
  pp3a_l1.forget
  pp3a_ncomp.forget

  # Rule PP.3bi: Space to NCOMP: For Inside DNWELL. (i) NCOMP space to LVPWELL >= 0.43um is 0.08µm.
  logger.info('Executing rule PP.3bi')
  pp_3bi_ncomp = ncomp.not(lvpwell_dn_sized_out)
  pp3bi_l1 = pp3_pplus.and(dnwell).separation(pp_3bi_ncomp, 0.08.um, euclidian)
  pp3bi_l1.output('PP.3bi',
                  'PP.3bi : Space to NCOMP: For Inside DNWELL. (i) NCOMP space to LVPWELL >= 0.43um: 0.08µm')
  pp3bi_l1.forget
  pp_3bi_ncomp.forget

  # Rule PP.3bii: Space to NCOMP: For Inside DNWELL.
  ## (ii) NCOMP space to LVPWELL < 0.43um. is 0.16µm
  logger.info('Executing rule PP.3bii')
  pp_3bii_ncomp = ncomp.and(lvpwell_dn_sized_out)
  pp3bii_l1 = pp3_pplus.and(dnwell).separation(pp_3bii_ncomp, 0.16.um, euclidian)
  pp3bii_l1.output('PP.3bii', "PP.3bii : Space to NCOMP: For Inside DNWELL.
                      (ii) NCOMP space to LVPWELL < 0.43um. : 0.16µm")
  pp3bii_l1.forget
  pp_3bii_ncomp.forget

  # Rule PP.3ci: Space to NCOMP: For Outside DNWELL, inside Nwell:
  ## (i) NWELL Overlap of NCOMP >= 0.43um is 0.08µm.
  logger.info('Executing rule PP.3ci')
  pp_3ci_ncomp = ncomp.and(nwell_n_dn_sized_in)
  pp3ci_l1 = pp3_pplus.and(nwell_n_dn).separation(pp_3ci_ncomp, 0.08.um, euclidian)
  pp3ci_l1.output('PP.3ci', "PP.3ci : Space to NCOMP: For Outside DNWELL, inside Nwell:
                    (i) NWELL Overlap of NCOMP >= 0.43um: 0.08µm")
  pp3ci_l1.forget
  pp_3ci_ncomp.forget

  # Rule PP.3cii: Space to NCOMP: For Outside DNWELL, inside Nwell:
  ## (ii) NWELL Overlap of NCOMP 0.43um. is 0.16µm
  logger.info('Executing rule PP.3cii')
  pp_3cii_ncomp = ncomp.and(nwell_n_dn.not(nwell_n_dn_sized_in))
  pp3cii_l1 = pp3_pplus.and(nwell_n_dn).separation(pp_3cii_ncomp, 0.16.um, euclidian)
  pp3cii_l1.output('PP.3cii', "PP.3cii : Space to NCOMP: For Outside DNWELL, inside Nwell:
                     (ii) NWELL Overlap of NCOMP 0.43um. : 0.16µm")
  pp3cii_l1.forget
  pp_3cii_ncomp.forget

  # Rule PP.3d: Min/max space to a butted NCOMP is 0um.
  logger.info('Executing rule PP.3d')
  pp3d_l1 = pcomp.and(ncomp)
  pp3d_l1.output('PP.3d', 'PP.3d : Min/max space to a butted NCOMP: 0um')
  pp3d_l1.forget

  # Rule PP.3e: Space to NCOMP edge adjacent to a butting edge is 0um.
  logger.info('Executing rule PP.3e')
  pp3e_l1 = pplus.and(ncomp)
  pp3e_l1.output('PP.3e', 'PP.3e : Space to NCOMP edge adjacent to a butting edge: 0um')
  pp3e_l1.forget

  # Rule PP.4a: Space related to N-channel gate at a butting edge parallel to gate. is 0.32µm
  logger.info('Executing rule PP.4a')
  pp4a_l1 = pplus_edges.and(ncomp_edges).separation(ngate.edges, 0.32.um, projection)
  pp4a_l1.output('PP.4a', 'PP.4a : Space related to N-channel gate at a butting edge parallel to gate. : 0.32µm')
  pp4a_l1.forget

  # Rule PP.4b: Within 0.32um of channel, space to N-channel gate
  ## extension perpendicular to the direction of Poly2.
  logger.info('Executing rule PP.4b')
  pp_4b_poly = poly2_drawn.edges.interacting(ngate.edges.not(ncomp_edges)).centers(0, 0.99).and(ngate.sized(0.32.um))
  pp4b_l1 = pplus.interacting(pplus_edges.separation(pp_4b_poly, 0.22.um, projection).polygons(0.001.um))
  pp4b_l1.output('PP.4b', "PP.4b : Within 0.32um of channel, space to N-channel gate
                    extension perpendicular to the direction of Poly2.")
  pp4b_l1.forget
  pp_4b_poly.forget

  # Rule PP.5a: Overlap of P-channel gate. is 0.23µm
  logger.info('Executing rule PP.5a')
  pp5a_l1 = pplus.enclosing(pgate, 0.23.um, euclidian).polygons(0.001.um)
  pp5a_l2 = pgate.not_outside(pplus).not(pplus)
  pp5a_l  = pp5a_l1.or(pp5a_l2)
  pp5a_l.output('PP.5a', 'PP.5a : Overlap of P-channel gate. : 0.23µm')
  pp5a_l1.forget
  pp5a_l2.forget
  pp5a_l.forget

  # Rule PP.5b: Extension beyond COMP for COMP
  ## (1) Inside NWELL (2) outside LVPWELL but inside DNWELL. is 0.16µm
  logger.info('Executing rule PP.5b')
  pp5b_pplus_slct = pplus.edges.not(pplus_butted_edges)
  pp5b_pplus = pp5b_pplus_slct.and(nwell).join(pp5b_pplus_slct.not(lvpwell).and(dnwell))
  pp5b_l1 = pcomp.edges.enclosed(pp5b_pplus, 0.16.um, projection)
  pp5b_l1.output('PP.5b', 'PP.5b : Extension beyond COMP for COMP
                 (1) Inside NWELL (2) outside LVPWELL but inside DNWELL. : 0.16µm')
  pp5b_l1.forget
  pp5b_pplus.forget
  pp5b_pplus_slct.forget

  # Rule PP.5ci: Extension beyond COMP: For Inside DNWELL, inside LVPWELL:
  ##  (i) For LVPWELL overlap of Pplus >= 0.43um for LVPWELL tap. is 0.02µm
  logger.info('Executing rule PP.5ci')
  pp_5ci_background = pplus.not_outside(lvpwell).inside(dnwell).edges.not(nplus_edges)
  pp_5ci_foreground = pcomp.not_outside(lvpwell).inside(dnwell).edges.not(nplus_edges).inside_part(lvpwell_dn_sized_in)
  pp5ci_l1 = pp_5ci_background.enclosing(pp_5ci_foreground, 0.02.um, euclidian)
  pp5ci_l1.output('PP.5ci', "PP.5ci : Extension beyond COMP: For Inside DNWELL, inside LVPWELL:
                    (i) For LVPWELL overlap of Pplus >= 0.43um for LVPWELL tap. : 0.02µm")
  pp5ci_l1.forget
  pp_5ci_background.forget
  pp_5ci_foreground.forget

  # Rule PP.5cii: Extension beyond COMP: For Inside DNWELL, inside LVPWELL:
  ## (ii) For LVPWELL overlap of Pplus < 0.43um for the LVPWELL tap. is 0.16µm
  logger.info('Executing rule PP.5cii')
  pp_5cii_background = pplus.not_outside(lvpwell).inside(dnwell).edges
  pp_5cii_extend = lvpwell_dn.not(lvpwell_dn_sized_in)
  pp_5cii_foreground = pcomp.not_outside(lvpwell).inside(dnwell).edges.not(nplus_edges).and(pp_5cii_extend)
  pp5cii_l1 = pp_5cii_background.enclosing(pp_5cii_foreground, 0.16.um, projection)
  pp5cii_l1.output('PP.5cii', "PP.5cii : Extension beyond COMP: For Inside DNWELL, inside LVPWELL:
                     (ii) For LVPWELL overlap of Pplus < 0.43um for the LVPWELL tap. : 0.16µm")
  pp5cii_l1.forget
  pp_5cii_background.forget
  pp_5cii_extend.forget
  pp_5cii_foreground.forget
  lvpwell_dn_sized_in.forget

  # Rule PP.5di: Extension beyond COMP: For Outside DNWELL
  ## (i) For Pplus to NWELL space >= 0.43um for Pfield or LVPWELL tap. is 0.02µm
  logger.info('Executing rule PP.5di')
  pp_5d_background = pplus.not_interacting(guard_ring_mk).outside(dnwell).edges
  pp_5d_pcomp = pcomp.outside(dnwell).edges
  pp_5di_foreground = pp_5d_pcomp.not(nplus_edges).not(nwell_n_dn_sized_out)
  pp5di_l1 = pp_5d_background.enclosing(pp_5di_foreground, 0.02.um, projection)
  pp5di_l1.output('PP.5di', "PP.5di : Extension beyond COMP: For Outside DNWELL
                    (i) For Pplus to NWELL space >= 0.43um for Pfield or LVPWELL tap. : 0.02µm")
  pp5di_l1.forget
  pp_5di_foreground.forget

  # Rule PP.5dii: Extension beyond COMP: For Outside DNWELL
  ## (ii) For Pplus to NWELL space < 0.43um for Pfield or LVPWELL tap. is 0.16µm
  logger.info('Executing rule PP.5dii')
  pp_5dii_foreground = pp_5d_pcomp.not(nplus_edges).and(nwell_n_dn_sized_out)
  pp5dii_l1 = pp_5d_background.enclosing(pp_5dii_foreground, 0.16.um, projection)
  pp5dii_l1.output('PP.5dii', "PP.5dii : Extension beyond COMP: For Outside DNWELL
                     (ii) For Pplus to NWELL space < 0.43um for Pfield or LVPWELL tap. : 0.16µm")
  pp5dii_l1.forget
  pp_5d_background.forget
  pp_5dii_foreground.forget
  nplus_edges.forget
  pp_5d_pcomp.forget
  nwell_n_dn_sized_out.forget

  # Rule PP.6: Overlap with PCOMP butted to NCOMP. is 0.22µm
  logger.info('Executing rule PP.6')
  pp6_l1 = comp.interacting(pplus).enclosing(ncomp.interacting(pplus), 0.22.um, projection).polygons
  pp6_l1.output('PP.6', 'PP.6 : Overlap with PCOMP butted to NCOMP. : 0.22µm')
  pp6_l1.forget

  # Rule PP.7: Space to unrelated unsalicided Poly2. is 0.18µm
  logger.info('Executing rule PP.7')
  pp7_l1 = pplus.separation(poly2_drawn.and(sab), 0.18.um, euclidian)
  pp7_l1.output('PP.7', 'PP.7 : Space to unrelated unsalicided Poly2. : 0.18µm')
  pp7_l1.forget

  # Rule PP.8a: Minimum Pplus area (um2). is 0.35µm²
  logger.info('Executing rule PP.8a')
  pp8a_l1 = pplus.with_area(nil, 0.35.um)
  pp8a_l1.output('PP.8a', 'PP.8a : Minimum Pplus area (um2). : 0.35µm²')
  pp8a_l1.forget

  # Rule PP.8b: Minimum area enclosed by Pplus (um2). is 0.35µm²
  logger.info('Executing rule PP.8b')
  pp8b_l1 = pplus.holes.raw.with_area(nil, 0.35.um)
  pp8b_l1.output('PP.8b', 'PP.8b : Minimum area enclosed by Pplus (um2). : 0.35µm²')
  pp8b_l1.forget

  # Rule PP.9: Overlap of unsalicided Poly2. is 0.18µm
  logger.info('Executing rule PP.9')
  pp9_l1 = pplus.enclosing(poly2_drawn.not_interacting(resistor).and(sab), 0.18.um, euclidian).polygons(0.001.um)
  pp9_l2 = poly2_drawn.not_interacting(resistor).and(sab).not_outside(pplus).not(pplus)
  pp9_l  = pp9_l1.or(pp9_l2)
  pp9_l.output('PP.9', 'PP.9 : Overlap of unsalicided Poly2. : 0.18µm')
  pp9_l1.forget
  pp9_l2.forget
  pp9_l.forget

  # Rule PP.10: Overlap of unsalicided COMP. is 0.18µm
  logger.info('Executing rule PP.10')
  pp10_l1 = pplus.enclosing(comp.and(sab), 0.18.um, euclidian)
  pp10_l1.output('PP.10', 'PP.10 : Overlap of unsalicided COMP. : 0.18µm')
  pp10_l1.forget

  # Rule PP.11: Butting Pplus and NCOMP is forbidden within 0.43um of Nwell edge
  ## (for outside DNWELL) and of LVPWELL edge (for inside DNWELL case).
  logger.info('Executing rule PP.11')
  pp_11_nwell_exclusion_area = nwell_n_dn.not(nwell_n_dn_sized_in)
  pp_11_lvpwell_exclude_area = lvpwell_dn_sized_out.not(lvpwell_dn)
  pp11_l1 = pplus_butted_edges.and(pp_11_nwell_exclusion_area)
  pp11_l2 = pplus_butted_edges.and(pp_11_lvpwell_exclude_area)
  pp11_l = pp11_l1.join(pp11_l2)
  pp11_l.output('PP.11', "PP.11 : Butting Pplus and NCOMP is forbidden within 0.43um of Nwell edge
                    (for outside DNWELL) and of LVPWELL edge (for inside DNWELL case).")
  pp11_l.forget
  pp11_l1.forget
  pp11_l2.forget
  pp_11_nwell_exclusion_area.forget
  pp_11_lvpwell_exclude_area.forget
  pplus_butted_edges.forget
  nwell_n_dn_sized_in.forget
  lvpwell_dn_sized_out.forget

  # Rule PP.12: Overlap with N-channel Poly2 gate extension is forbidden
  ##  within 0.32um of N-channel gate.
  logger.info('Executing rule PP.12')
  pp12_l1 = pplus.interacting(ngate.sized(0.32.um - 1.dbu, size_inside(poly2_drawn), steps(3)))
  pp12_l1.output('PP.12', "PP.12 : Overlap with N-channel Poly2 gate extension is forbidden
                    within 0.32um of N-channel gate.")
  pp12_l1.forget
  pplus_edges.forget
  ncomp_edges.forget
end
