# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all mim mim_b]
) do
  next unless ctx.mim_option == 'B'

  #================================================
  #-------------MIM CAPACITOR OPTION B-------------
  #================================================

  logger.info('MIM Capacitor Option B section')

  mimtm_virtual = fusetop.sized(1.06.um).and(topmin1_metal.interacting(fusetop))

  # Rule MIMTM.1: Minimum MiM bottom plate spacing to the bottom plate metal
  ## (whether adjacent MiM or routing metal). is 1.2µm
  logger.info('Executing rule MIMTM.1')
  mimtm1_l1 = topmin1_metal.separation(mimtm_virtual, transparent, 1.2.um)
  mimtm1_l1.output('MIMTM.1', "MIMTM.1 : Minimum MiM bottom plate spacing to the bottom plate metal
                      (whether adjacent MiM or routing metal). : 1.2µm")
  mimtm1_l1.forget

  # Rule MIMTM.2: Minimum MiM bottom plate overlap of Vian-1 layer.
  ## [This is applicable for Vian-1 within 1.06um oversize of FuseTop layer
  ## (referenced to virtual bottom plate)]. is 0.4µm
  logger.info('Executing rule MIMTM.2')
  mimtm_via = top_via.overlapping(mimtm_virtual)
  mimtm2_l1 = mimtm_via.enclosed(topmin1_metal, 0.4.um, euclidian).polygons(0.001.um)
  mimtm2_l2 = mimtm_via.not_outside(topmin1_metal).not(topmin1_metal)
  mimtm2_l  = mimtm2_l1.join(mimtm2_l2)
  mimtm2_l.output('MIMTM.2', "MIMTM.2 : Minimum MiM bottom plate overlap of Vian-1 layer.
                    [This is applicable for Vian-1 within 1.06um oversize of FuseTop layer
                    (referenced to virtual bottom plate)]. : 0.4µm")
  mimtm2_l1.forget
  mimtm2_l2.forget
  mimtm2_l.forget
  mimtm_via.forget

  # Rule MIMTM.3: Minimum MiM bottom plate overlap of Top plate.
  logger.info('Executing rule MIMTM.3')
  mimtm3_l1 = fusetop.enclosed(mimtm_virtual, 0.6.um).polygons(0.001.um)
  mimtm3_l2 = fusetop.not_inside(mimtm_virtual)
  mimtm3_l = mimtm3_l1.join(mimtm3_l2)
  mimtm3_l.output('MIMTM.3', 'MIMTM.3 : Minimum MiM bottom plate overlap of Top plate.')
  mimtm3_l.forget
  mimtm3_l1.forget
  mimtm3_l2.forget
  mimtm_virtual.forget

  # Rule MIMTM.4: Minimum MiM top plate (FuseTop) overlap of Vian-1 is 0.4µm.
  logger.info('Executing rule MIMTM.4')
  mimtm4_l1 = fusetop.enclosing(top_via, 0.4.um, euclidian).polygons(0.001.um)
  mimtm4_l2 = top_via.not_outside(fusetop).not(fusetop)
  mimtm4_l  = mimtm4_l1.join(mimtm4_l2)
  mimtm4_l.output('MIMTM.4', 'MIMTM.4 : Minimum MiM top plate (FuseTop) overlap of Vian-1: 0.4µm')
  mimtm4_l1.forget
  mimtm4_l2.forget
  mimtm4_l.forget

  # Rule MIMTM.5: Minimum spacing between top plate and the Vian-1 connecting to the bottom plate. is 0.4µm
  logger.info('Executing rule MIMTM.5')
  mimtm5_l1 = fusetop.separation(top_via.interacting(topmin1_metal), 0.4.um, euclidian)
  mimtm5_l1.output('MIMTM.5',
                   'MIMTM.5 : Minimum spacing between top plate and the Vian-1 connecting to the bottom plate. : 0.4µm')
  mimtm5_l1.forget

  # Rule MIMTM.6: Minimum spacing between unrelated top plates is 0.6µm.
  logger.info('Executing rule MIMTM.6')
  mimtm6_l1 = fusetop.space(0.6.um, euclidian)
  mimtm6_l1.output('MIMTM.6', 'MIMTM.6 : Minimum spacing between unrelated top plates: 0.6µm')
  mimtm6_l1.forget

  # Rule MIMTM.7: Min FuseTop enclosure by CAP_MK is 0um.
  logger.info('Executing rule MIMTM.7')
  mimtm7_l1 = fusetop.not(cap_mk)
  mimtm7_l1.output('MIMTM.7', 'MIMTM.7 : Min FuseTop enclosure by CAP_MK: 0um.')
  mimtm7_l1.forget

  # Rule MIMTM.8a: Minimum MIM cap area (defined by FuseTop area) is 25µm².
  logger.info('Executing rule MIMTM.8a')
  mimtm8a_l1 = fusetop.with_area(nil, 25.um)
  mimtm8a_l1.output('MIMTM.8a', 'MIMTM.8a : Minimum MIM cap area (defined by FuseTop area): 25µm²')
  mimtm8a_l1.forget

  # Rule MIMTM.8b: Maximum single MIM Cap area (Use multiple MIM caps in
  ## parallel connection if bigger capacitors are required) (um2). is 10000µm
  logger.info('Executing rule MIMTM.8b')
  mimtm8b_l1 = fusetop.with_area(10_000.um, nil).not_in(fusetop.with_area(10_000.um))
  mimtm8b_l1.output('MIMTM.8b', "MIMTM.8b : Maximum single MIM Cap area (Use multiple MIM caps in
                       parallel connection if bigger capacitors are required) (um2). : 10000µm")
  mimtm8b_l1.forget

  # Rule MIMTM.9: Min. Via (Vian-1) spacing for sea of Via on MIM top plate. is 0.5µm
  logger.info('Executing rule MIMTM.9')
  mimtm9_l1 = top_via.inside(fusetop).space(0.5.um, euclidian)
  mimtm9_l1.output('MIMTM.9', 'MIMTM.9 : Min. Via (Vian-1) spacing for sea of Via on MIM top plate. : 0.5µm')
  mimtm9_l1.forget

  # Rule MIMTM.10: (a) There cannot be any Vian-2 touching MIM bottom plate Metaln-1.
  ## (b) MIM bottom plate Metaln-1 can only be connected through the higher Via (Vian-1).
  logger.info('Executing rule MIMTM.10')
  mimtm10_l1 = topmin1_via.and(topmin1_metal.and(fusetop))
  mimtm10_l1.output('MIMTM.10', "MIMTM.10 : (a) There cannot be any Vian-2 touching MIM bottom plate Metaln-1.
                      (b) MIM bottom plate Metaln-1 can only be connected through the higher Via (Vian-1).")
  mimtm10_l1.forget

  # Rule MIMTM.11: Bottom plate of multiple MIM caps can be shared (for common nodes)
  ## as long as total MIM area with that single common plate does not exceed MIMTM.8b rule. is -µm
  logger.info('Executing rule MIMTM.11')
  mimtm11_large_topmin1_metal = topmin1_metal.interacting(fusetop).with_area(10_000, nil)
  mimtm11_large_topmin1_metal_violation = polygon_layer
  mimtm11_large_topmin1_metal.data.each do |p|
    mimtm11_topmin1_metal_polygon_layer = polygon_layer
    mimtm11_topmin1_metal_polygon_layer.data.insert(p)
    fuse_in_polygon = fusetop.and(mimtm11_topmin1_metal_polygon_layer)
    next unless fuse_in_polygon.area > 10_000

    mimtm11_bad_topmin1_metal_polygon = mimtm11_topmin1_metal_polygon_layer.interacting(fuse_in_polygon)
    mimtm11_bad_topmin1_metal_polygon.data.each do |b|
      b.num_points.positive? && mimtm11_large_topmin1_metal_violation.data.insert(b)
    end
  end
  mimtm11_l1 = mimtm11_large_topmin1_metal_violation
  mimtm11_l1.output('MIMTM.11',
                    'MIMTM.11 : Bottom plate of multiple MIM caps can be shared (for common nodes)
                     as long as total MIM area with that single common plate does not exceed MIMTM.8b rule. : -µm')
  mimtm11_l1.forget
  mimtm11_large_topmin1_metal.forget
  mimtm11_large_topmin1_metal_violation.forget

  # Rule MIMTM.12 is not a DRC check
  # Please refer to https://gf180mcu-pdk.readthedocs.io/en/latest/physical_verification/design_manual/drm_10_4_2.html
end
