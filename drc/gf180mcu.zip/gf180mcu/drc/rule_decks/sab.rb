# frozen_string_literal: true

################################################################################################
# Copyright 2022 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################
GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all feol sab]
) do
  #================================================
  #----------------------SAB-----------------------
  #================================================

  # sab derivations
  logger.info('Starting sab derivations')

  sab_out_otp = sab.outside(otp_mk)
  poly_sab = poly2_drawn.interacting(sab)
  comp_sab = comp.interacting(sab)
  sab_poly = sab.and(poly2_drawn)

  # Rule SB.1: min. sab width is 0.42µm
  logger.info('Executing rule SB.1')
  sb1_l1 = sab.width(0.42.um, euclidian)
  sb1_l1.output('SB.1', 'SB.1 : min. sab width : 0.42µm')
  sb1_l1.forget

  # Rule SB.2: min. sab spacing is 0.42µm
  logger.info('Executing rule SB.2')
  sb2_l1 = sab_out_otp.space(0.42.um, euclidian)
  sb2_l1.output('SB.2', 'SB.2 : min. sab spacing : 0.42µm')
  sb2_l1.forget

  # Rule SB.3: Space from salicide block to unrelated COMP. is 0.22µm
  logger.info('Executing rule SB.3')
  sb13_comp = comp.not_overlapping(sab_out_otp)
  sb3_l1 = sab_out_otp.separation(sb13_comp, 0.22.um, euclidian)
  sb3_l1.output('SB.3', 'SB.3 : Space from salicide block to unrelated COMP. : 0.22µm')
  sb3_l1.forget
  sb13_comp.forget

  # Rule SB.4: Space from salicide block to contact is 0.15 um.
  logger.info('Executing rule SB.4')
  sb4_l1 = sab_out_otp.separation(contact, 0.15.um, euclidian).polygons(0.001.um).or(sab_out_otp.and(contact))
  sb4_l1.output('SB.4', 'SB.4 : Space from salicide block to contact: 0.15 um')
  sb4_l1.forget

  # Rule SB.5a: Space from salicide block to unrelated Poly2 on field. is 0.3µm
  logger.info('Executing rule SB.5a')
  sb5a_poly = poly2_drawn.not(comp).not_overlapping(sab)
  sb5a_l1 = sab_out_otp.separation(sb5a_poly, 0.3.um, euclidian)
  sb5a_l1.output('SB.5a', 'SB.5a : Space from salicide block to unrelated Poly2 on field. : 0.3µm')
  sb5a_l1.forget
  sb5a_poly.forget

  # Rule SB.5b: Space from salicide block to unrelated Poly2 on COMP. is 0.28µm
  logger.info('Executing rule SB.5b')
  sb5b_l1 = sab_out_otp.separation(poly2_drawn.and(comp), 0.28.um, euclidian)
  sb5b_l1.output('SB.5b', 'SB.5b : Space from salicide block to unrelated Poly2 on COMP. : 0.28µm')
  sb5b_l1.forget

  # Rule SB.6: Salicide block extension beyond related COMP. is 0.22µm
  logger.info('Executing rule SB.6')
  sb6_l1 = comp_sab.enclosed(sab, 0.22.um, euclidian)
  sb6_l1.output('SB.6', 'SB.6 : Salicide block extension beyond related COMP. : 0.22µm')
  sb6_l1.forget

  # Rule SB.7: COMP extension beyond related salicide block. is 0.22µm
  logger.info('Executing rule SB.7')
  sb7_l1 = sab.enclosed(comp_sab, 0.22.um, euclidian).polygons
  sb7_l1.output('SB.7', 'SB.7 : COMP extension beyond related salicide block. : 0.22µm')
  sb7_l1.forget

  # Rule SB.8: Non-salicided contacts are forbidden.
  logger.info('Executing rule SB.8')
  sb8_l1 = contact.and(sab)
  sb8_l1.output('SB.8', 'SB.8 : Non-salicided contacts are forbidden.')
  sb8_l1.forget

  # Rule SB.9: Salicide block extension beyond unsalicided Poly2. is 0.22µm
  logger.info('Executing rule SB.9')
  sb9_l1 = poly_sab.enclosed(sab_out_otp, 0.22.um, euclidian).polygons
  sb9_l1.output('SB.9', 'SB.9 : Salicide block extension beyond unsalicided Poly2. : 0.22µm')
  sb9_l1.forget

  # Rule SB.10: Poly2 extension beyond related salicide block. is 0.22µm
  logger.info('Executing rule SB.10')
  sb10_l1 = sab.enclosed(poly_sab, 0.22.um, euclidian)
  sb10_l1.output('SB.10', 'SB.10 : Poly2 extension beyond related salicide block. : 0.22µm')
  sb10_l1.forget

  # Rule SB.11: Overlap with COMP. is 0.22µm
  logger.info('Executing rule SB.11')
  sb11_l1 = sab_out_otp.overlap(comp_sab, 0.22.um, euclidian).polygons
  sb11_l1.output('SB.11', 'SB.11 : Overlap with COMP. : 0.22µm')
  sb11_l1.forget
  comp_sab.forget

  # Rule SB.12: Overlap with Poly2 outside ESD_MK is 0.22µm.
  logger.info('Executing rule SB.12')
  sb12_l1 = sab_out_otp.outside(esd_mk).overlap(poly_sab, 0.22.um, euclidian).polygons
  sb12_l1.output('SB.12', 'SB.12 : Overlap with Poly2 outside ESD_MK : 0.22µm')
  sb12_l1.forget
  poly_sab.forget

  # Rule SB.13: Min. area (um2) is 2µm².
  logger.info('Executing rule SB.13')
  sb13_l1 = sab_out_otp.with_area(nil, 2.um)
  sb13_l1.output('SB.13', 'SB.13 : Min. area (um2) : 2µm²')
  sb13_l1.forget

  # Rule SB.14a: Space from unsalicided Nplus Poly2 to unsalicided Pplus Poly2.
  ## (Unsalicided Nplus Poly2 must not fall within a square of 0.56um x 0.56um
  ## at unsalicided Pplus Poly2 corners). is 0.56µm
  logger.info('Executing rule SB.14a')
  sb14a_butted_sab_poly = sab_poly.and(pplus).edges.inside(sab_poly.and(nplus).edges)
  sb14a_l1 = sab_poly.and(nplus).separation(sab_poly.and(pplus), 0.56.um,
                                            square).polygons(0.001.um).not_interacting(sb14a_butted_sab_poly)
  sb14a_l1.output('SB.14a', "SB.14a : Space from unsalicided Nplus Poly2 to unsalicided Pplus Poly2.
                    (Unsalicided Nplus Poly2 must not fall within a square of 0.56um x 0.56um
                    at unsalicided Pplus Poly2 corners). : 0.56µm")
  sb14a_l1.forget
  sb14a_butted_sab_poly.forget

  # Rule SB.14b: Space from unsalicided Nplus Poly2 to P-channel gate.
  ## (Unsalicided Nplus Poly2 must not fall within a square of 0.56um x 0.56um
  ## at P-channel gate corners). is 0.56µm
  logger.info('Executing rule SB.14b')
  sb14b_l1 = sab_poly.and(nplus).separation(pgate, 0.56.um, square)
  sb14b_l1.output('SB.14b', "SB.14b : Space from unsalicided Nplus Poly2 to P-channel gate.
                    (Unsalicided Nplus Poly2 must not fall within a square of 0.56um x 0.56um
                    at P-channel gate corners). : 0.56µm")
  sb14b_l1.forget

  # Rule SB.15a: Space from unsalicided Poly2 to unrelated Nplus/Pplus. is 0.18µm
  logger.info('Executing rule SB.15a')
  sb15a_np = nplus.or(pplus).not_overlapping(sab_poly)
  sb15a_l1 = sab_poly.separation(sb15a_np, 0.18.um, euclidian)
  sb15a_l1.output('SB.15a', 'SB.15a : Space from unsalicided Poly2 to unrelated Nplus/Pplus. : 0.18µm')
  sb15a_l1.forget
  sb15a_np.forget
  sab_poly.forget

  # Rule SB.15b: Space from unsalicided Poly2 to unrelated Nplus/Pplus along Poly2 line is 0.32 um
  logger.info('Executing rule SB.15b')
  sb15b_np = nplus.or(pplus).interacting(poly2_drawn.interacting(sab_out_otp))
  sb15b_poly = poly2_drawn.overlapping(sb15b_np).and(sab_out_otp)
  sb15b_l1 = sb15b_poly.separation(sb15b_np, 0.32.um, euclidian)
  sb15b_l1.output('SB.15b', 'SB.15b : Space from unsalicided Poly2 to unrelated Nplus/Pplus. : 0.32µm')
  sb15b_l1.forget
  sb15b_np.forget
  sb15b_poly.forget

  # Rule SB.16: SAB layer cannot exist on 3.3V and 5V/6V CMOS transistors'
  ## Poly and COMP area of the core circuit (Excluding the transistors used for ESD purpose).
  ## It can only exist on CMOS transistors marked by LVS_IO, OTP_MK, ESD_MK layers.
  logger.info('Executing rule SB.16')
  sb16_exclude = sab_out_otp.outside(lvs_io.or(esd_mk))
  sb16_l1 = sb16_exclude.interacting(tgate)
  sb16_l1.output('SB.16', "SB.16 : SAB layer cannot exist on 3.3V and 5V/6V CMOS transistors'
                    Poly and COMP area of the core circuit (Excluding the transistors used for ESD purpose).
                    It can only exist on CMOS transistors marked by LVS_IO, OTP_MK, ESD_MK layers.")
  sb16_l1.forget
  sb16_exclude.forget
  sab_out_otp.forget
end
