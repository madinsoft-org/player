# frozen_string_literal: true

################################################################################################
# Copyright 2023 GlobalFoundries PDK Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################################

GF180_DRC_REGISTRY.register(
  id: File.basename(__FILE__, File.extname(__FILE__)),
  path: __FILE__,
  priority: 0,
  tags: %w[all beol metaltop_30k]
) do
  next unless ctx.metal_top == '30K'

  #================================================
  #---------------- METALTOP 30K ------------------
  #================================================

  logger.info('MetalTop thickness 30K section')

  # Rule MT30.1a: Min. thick MetalTop width. is 1.8µm
  logger.info('Executing rule MT30.1a')
  mt301a_l1 = top_metal.width(1.8.um, euclidian)
  mt301a_l1.output('MT30.1a', 'MT30.1a : Min. thick MetalTop width. : 1.8µm')
  mt301a_l1.forget

  # Rule MT30.1b: Min width for >1000um long metal line (based on metal edge). is 2.2µm
  logger.info('Executing rule MT30.1b')
  long_edge = top_metal.edges.with_length(1000.um, nil)
  mt301b_l1 = top_metal.interacting(long_edge).width(2.2.um, euclidian)
  mt301b_l1.output('MT30.1b', 'MT30.1b : Min width for >1000um long metal line (based on metal edge). : 2.2µm')
  mt301b_l1.forget
  long_edge.forget

  # Rule MT30.2: Min. thick MetalTop space. is 1.8µm
  logger.info('Executing rule MT30.2')
  mt302_l1 = top_metal.space(1.8.um, euclidian)
  mt302_l1.output('MT30.2', 'MT30.2 : Min. thick MetalTop space. : 1.8µm')
  mt302_l1.forget

  # Rule MT30.3: The separation of two corners should satisfy the minimum spacing. is 1.8µm
  logger.info('Executing rule MT30.4')
  mt303_l1 = top_metal.space(1.8.um, euclidian)
  mt303_l1.output('MT30.3', 'MT30.3 : The separation of two corners should satisfy the minimum spacing. : 1.8µm')
  mt303_l1.forget

  # Rule MT30.4: The separation of single metal line from a any degree
  ## metal line should satisfy the minimum spacing is 1.8µm
  logger.info('Executing rule MT30.4')
  mt304_l1 = top_metal.space(1.8.um, euclidian)
  mt304_l1.output('MT30.4', "MT30.4 : The separation of single metal line from a any degree
                         metal line should satisfy the minimum spacing : 1.8µm")
  mt304_l1.forget

  # Rule MT30.5: Minimum thick MetalTop enclose underlying via
  ## (for example: via5 for 6LM case) [Outside Not Allowed] is 0.12um.
  logger.info('Executing rule MT30.5')
  mt305_l1 = top_via.enclosed(top_metal, 0.12.um, euclidian).polygons(0.001.um)
  mt305_l2 = top_via.not_inside(top_metal)
  mt305_l = mt305_l1.join(mt305_l2)
  mt305_l.output('MT30.5', "MT30.5 : Minimum thick MetalTop enclose underlying via
                       (for example: via5 for 6LM case) [Outside Not Allowed]: 0.12um")
  mt305_l.forget
  mt305_l1.forget
  mt305_l2.forget

  # Rule MT30.6: Thick MetalTop end-of-line (width <2.5um) enclose underlying via
  ## (for example: via5 for 6LM case) [Outside Not Allowed] is 0.25um.
  logger.info('Executing rule MT30.6')
  mt30p6_cond = top_metal.width(2.5.um)
  mt30p6_cond_edge1 = mt30p6_cond.first_edges
  mt30p6_cond_edge2 = mt30p6_cond.second_edges
  mt30p6_eol_allowed = top_metal.edges.with_length(nil, 2.5.um)
  mt30p6_eol = mt30p6_eol_allowed.interacting(mt30p6_cond_edge1).interacting(mt30p6_cond_edge2)
                                 .not(mt30p6_cond_edge1).not(mt30p6_cond_edge2)
  mt306_l1 = mt30p6_eol.enclosing(top_via.edges, 0.25.um, projection)
  mt306_l1.output('MT30.6', "MT30.6 : Thick MetalTop end-of-line (width <2.5um) enclose underlying via
                        (for example: via5 for 6LM case) [Outside Not Allowed]: 0.25um")
  mt306_l1.forget
  mt30p6_cond.forget
  mt30p6_eol.forget
  mt30p6_cond_edge1.forget
  mt30p6_cond_edge2.forget
  mt30p6_eol_allowed.forget

  logger.info('Executing rule MT30.8')
  mt308_egde_length = (0.26 * 1) + (1 * 0.26)
  top_via_not_seal_ring = top_via.not(guard_ring_mk)
  metal_top_intersections = top_metal.and(topmin1_metal).not(guard_ring_mk).interacting(top_via_not_seal_ring)
  mt308_l1 = metal_top_intersections.interacting(top_via_not_seal_ring, 1, 3)
  mt308_poss_l2 = metal_top_intersections.interacting(top_via_not_seal_ring, 4..nil)
  mt308_poss_via = top_via_not_seal_ring.interacting(mt308_poss_l2)

  # Rule MT30.8: There shall be minimum 2X2 array of vias
  ## (top vias) at one location connecting to 3um thick top metal.
  mt308_poss_via_over_under = size_overunder_in_layers(metal_top_intersections, mt308_poss_via, 1.0)
  mt308_all = mt308_poss_via_over_under.with_bbox_min(mt308_egde_length..nil)
  mt308_loc_exc = mt308_all.width(mt308_egde_length,
                                  projection_limits(mt308_egde_length..(1000 * mt308_egde_length))).polygons
  mt308_loc = mt308_all.not_interacting(mt308_loc_exc)
  mt308_l2 = mt308_poss_l2.not_interacting(mt308_loc)
  mt308_l3 = mt308_poss_via_over_under.non_rectangles
  mt308_l = mt308_l1.join(mt308_l2).join(mt308_l3)

  # The code below is an imperfect implementation (heuristic) of MT30.8.
  # It is much faster than the perfect implementation above.
  # As 30K design is rarely used, and a dedicated switch was required to select
  # the slow or fast implementation, it was decided to drop the heuristic.
  # The code here is provided for historical purposes, if the 30K options becomes
  # popular
  # mt308_poss_via_over_under = mt308_poss_via.sized(0.3, 'square_limit').merged.sized(-0.3,
  #                                                                                    'square_limit')
  # mt308_all = mt308_poss_via_over_under.with_bbox_min(mt308_egde_length..nil)
  # mt308_loc_exc = mt308_all.width(mt308_egde_length,
  #                                 projection_limits(mt308_egde_length..(1000 * mt308_egde_length))).polygons
  # mt308_loc = mt308_all.not_interacting(mt308_loc_exc)
  # mt308_l2 = mt308_poss_l2.not_interacting(mt308_loc)
  # mt308_l = mt308_l1.join(mt308_l2)

  mt308_l.output('MT30.8', 'MT30.8 : There shall be minimum 2X2 array of vias
                        (top vias) at one location connecting to 3um thick top metal.')
  top_via_not_seal_ring.forget
  metal_top_intersections.forget
  mt308_l1.forget
  mt308_poss_l2.forget
  mt308_poss_via.forget
  mt308_poss_via_over_under.forget
  mt308_all.forget
  mt308_loc_exc.forget
  mt308_loc.forget
  mt308_l2.forget
  mt308_l.forget
end
